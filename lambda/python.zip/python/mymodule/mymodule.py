def greet():
    print("Hello Good Morning")

